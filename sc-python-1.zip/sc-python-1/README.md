Python session 1

This contains:
Stub notebooks
Data files
PDF Python cheatsheet
