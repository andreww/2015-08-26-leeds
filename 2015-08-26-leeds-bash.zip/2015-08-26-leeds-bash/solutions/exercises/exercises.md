## Excercise 1

I did the following:
```
cd data/users
mkdir andrew
cd andrew
nano aims.txt
cp ../nelle/molecules/* .
```

## Excercise 2

I did the following:
```
grep ' H ' *.pdb | wc -l
```

Note that you need the spaces around the 
H to avoid counting lines from the header.
