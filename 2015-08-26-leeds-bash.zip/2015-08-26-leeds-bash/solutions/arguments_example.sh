echo $1
echo "${*:2}"
