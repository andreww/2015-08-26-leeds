
head $1 $3 | tail $2

