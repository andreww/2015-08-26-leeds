for filename in *.pdb
    do
        cp $filename $filename.backup
    done
