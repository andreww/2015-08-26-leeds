for var in $*
 do
  echo -n $var
  grep ' C ' $var | wc -l
 done
