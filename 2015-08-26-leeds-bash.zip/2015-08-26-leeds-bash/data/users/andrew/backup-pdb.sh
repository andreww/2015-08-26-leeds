for file in *.pdb
   do
       cp $file $file.backup
   done
